# iMails-The-Mailing-Site

All copyrights reserved by iMails 2019

**Steps to start project:**

1. Download the project.
2. Extract files and copy extracted file in your C://xampp/htdocs folder.
3. Now your folder looks like this: - C://xampp/htdocs/imails/...</br>
                                                              /database</br>
                                                              /forms</br>
                                                              /images</br>
                                                              /mail</br>
                                                              /non-pages</br>
                                                              /pages</br>
                                                              /repository</br>
                                                              /settings</br>
                                                              /imails.sql</br>
                                                              /index.php</br>
                                                              /main.min.css</br>
                                                              /my.css</br>
                                                             
4. Start all services of xampp from xampp panel.
5. Now create new database in phpmyadmin
6. Open C://xampp/htdocs/imails/**imails.sql** copy all contain and paste it on sql panel of your database. </br>
    **Note: Don't import imails.sql file because size of file is larger.**
7. Change database username and password, if you have changed or keep as it is in **database/db.inc.php**
8. Now your project is ready to run
    open this link on your browser http://localhost/imails
    
Thank You for your support!!!

**Please follow us on:**

https://www.facebook.com/InvertBitt/  </br>
https://youtu.be/dPcJc_htxw8  </br>
https://twitter.com/Ankesh_AAG  </br>
https://github.com/ankesh06g  </br>
