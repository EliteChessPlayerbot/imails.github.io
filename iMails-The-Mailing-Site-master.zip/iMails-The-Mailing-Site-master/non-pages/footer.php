    <footer>
        <div class="footer">
            <style>
                .fab{
                    font-size:21px;
                }
            </style>
            <center>
                <a href="https://www.facebook.com/CompRepository-457159251436485" target="_blank"><i class="fab fa-facebook-f"></i></a>&nbsp;&nbsp;
                    <a href="https://twitter.com/Ankesh_AAG"><i class="fab fa-twitter" target="_blank"></i></a>&nbsp;&nbsp;
                    <a href="https://github.com/ankesh06g"><i class="fab fa-github" target="_blank"></i></a>&nbsp;&nbsp;
                    <a href="https://www.youtube.com/channel/UCajCBee6FiNo-gRHoGd-PCA" target="_blank"><i class="fab fa-youtube"></i></a>&nbsp;&nbsp;
                    <a href=https://linkedin.com/in/ankesh-gaikwad-4a2701134"><i class="fab fa-linkedin-in" target="_blank"></i></a><br>
                <span class="copyright">All copyrights reserved © iMails 2018
                </span>
            </center>
        </div>
    </footer>
    <script src="../repository/js/jquery.min.js" type="text/javascript"></script>
    <script src="../repository/js/main.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="../repository/js/bootstrap.min.js" type="text/javascript"></script>
  </body>
</html>